create view zadanie6 as select COUNT(Employees.City) as Licza_Pracowników, City from Employees inner join Cars ON Employees.ID = Cars.EMPLOYEE_ID  group by Employees.City
go

